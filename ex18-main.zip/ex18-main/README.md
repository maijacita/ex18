# ex18
Tein CRUD operaatiot vain tietokannan opiskelija osaan, eli sivulla voi ainoastaan lisätä, poistaa, tai muokata opiskelijan tietoja.
